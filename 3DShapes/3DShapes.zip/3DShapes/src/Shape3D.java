/*
 * File: Shape3D.java
 * 
 * Purpose: An abstract class with abstract methods that are implemented by other subclasses.
 * Implements the comparable interface that will allow the program to sort the shapes.
 * 
 * I affirm that this program is entirely
 * my own work and none of it is the work
 * of any other person.
 */

/**
 * Abstract class that defines the shape classes
 *
 * @author JuanS
 */
public abstract class Shape3D implements Comparable<Shape3D>
{
    private Point3D shapeCenter; // Variable for the center of the shape

    /**
     * Constructs the central point of the shape
     * @param x x-axis
     * @param y y-axis
     * @param z z-axis
     */
    public Shape3D(int x, int y, int z) {
        shapeCenter = new Point3D(x, y, z);
    }

    /**
     * Formulates the distance from the origin.
     *
     * @return the distance from the origin
     */
    public double distanceFromOrigin(){
        return Math.sqrt(
                Math.pow(shapeCenter.getX(), 2) +
                Math.pow(shapeCenter.getY(), 2) +
                Math.pow(shapeCenter.getZ(), 2)
        );
    }

    //Abstract method for the surface area of the shape
    public abstract double shapeSurface();

    //Abstract method for the volume of the shape
    public abstract double shapeVolume();

    /**
     * Implementation of the comparable interface.
     *
     * @param shape3D shape to be compared
     * @return sorted shapes by volume
     */
    @Override
    public int compareTo(Shape3D shape3D) {
        if(shape3D.shapeVolume() < this.shapeVolume()) return -1;
        if(shape3D.shapeVolume() > this.shapeVolume()) return 1;
        return 0;
    }

    /**
     * Abstract method to display the name and the measures of the shape.
     *
     * @return the name and measures of the shape
     */
    public abstract String getName();

    /**
     * Overrides the toString from the Point3D class.
     *
     * @return the coordinates of the point
     */
    @Override
    public String toString() {
        return shapeCenter.toString();
    }
}
