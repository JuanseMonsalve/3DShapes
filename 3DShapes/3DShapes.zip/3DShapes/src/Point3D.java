/*
 * File: Point3D.java
 * 
 * Purpose: A class that represents a pint.
 * 
 * I affirm that this program is entirely
 * my own work and none of it is the work
 * of any other person.
 */

/**
 * Represent a point in the cartesian plane.
 *
 * @author JuanS
 */
public class Point3D
{
    private int x; // position of x
    private int y; // position of y
    private int z; // position of z

    /**
     * Constructs the point.
     *
     * @param x x-axis
     * @param y y-axis
     * @param z z-axis
     */
    public Point3D(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /**
     * Gets the position of x.
     *
     * @return position of x
     */
    public int getX() {
        return x;
    }

    /**
     * Gets the position of y.
     *
     * @return position of y
     */
    public int getY() {
        return y;
    }

    /**
     * Gets the position of z.
     *
     * @return position of z
     */
    public int getZ() {
        return z;
    }

    /**
     * Displays the coordinates of the point.
     *
     * @return the point coordinates.
     */
    @Override
    public String toString() {
        return "x(" + x +
                ") y(" + y +
                ") z(" + z + ")";
    }
}
