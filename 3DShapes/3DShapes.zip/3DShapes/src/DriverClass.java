/*
 * File: DriverClass.java
 * 
 * Purpose: Creates 4 different shapes and sorts them by their volume and distance from the origin.
 * 
 * I affirm that this program is entirely
 * my own work and none of it is the work
 * of any other person.
 */

import java.util.Arrays;

/**
 * Creates 4 shapes and sorts them.
 *
 * @author JuanS
 */
public class DriverClass
{

    /**
     * Main class.
     * @param args the command line arguments
     */
    public static void main( String[] args )
    {
        Shape3D [] shapes = new Shape3D[4];// Array to store the 4 shapes.
        shapes[0] = new Sphere(2,5,8,14); // Creates a sphere shape.
        shapes[1] = new Cone(-5, 4, -1, 11, 15); // Creates a cone shape.
        shapes[2] = new Cylinder(-3, 4, -1, 14, 12); // Creates a cylinder shape.
        shapes[3] = new Parallelepiped(7,16, 9, 19, 9, 13); // Creates a parallelepiped shape.

        System.out.println("\u001B[1;31m" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::>");
        System.out.println("Show shapes" + "\u001B[0m" + "\n");

        //Displays the name and the characteristics of the shape.
        for(Shape3D currentShape : shapes){
            System.out.println(currentShape.toString());
            System.out.println("Surface Area: " + (double) Math.round(currentShape.shapeSurface()*100)/100 + "\n");
        }

        //Sorts the array of shapes by volume.
        Arrays.sort(shapes);

        System.out.println("\u001B[1;31m" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::>");
        System.out.println("Show shapes sorted by descending volume" + "\u001B[0m" + "\n");

        //Displays the name and and the volume of the shape
        for(Shape3D currentShape : shapes){
            System.out.println(currentShape.getName());
            System.out.println("Volume: " + (double) Math.round(currentShape.shapeVolume()*100)/100 + "\n");
        }

        //Sorts the array of shapes by distance from the origin.
        Arrays.sort(shapes, new ComparatorForShapes());

        System.out.println("\u001B[1;31m" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::>");
        System.out.println("Show shapes sorted by origin ascending" + "\u001B[0m" + "\n");

        //Displays the name and and the distance from the origin of the shape
        for(Shape3D currentShape : shapes){
            System.out.println(currentShape.getName());
            System.out.println("Distance from the origin: " + (double) Math.round(currentShape.distanceFromOrigin()*100)/100 + "\n");
        }

        System.out.println("\u001B[1;31m" + "<:::::::::::::::::::::::::the-end::::::::::::::::::::::::::>");
    }
    
}
