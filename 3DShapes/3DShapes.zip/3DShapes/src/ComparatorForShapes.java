/*
 * File: ComparatorForShapes.java
 *
 * Purpose: A class that implements the Comparator interface to sort the shapes.
 * 
 * I affirm that this program is entirely
 * my own work and none of it is the work
 * of any other person.
 */

import java.util.Comparator;

/**
 * Used to Sort the shapes in ascending order of distance from the origin.
 * @author JuanS
 */
public class ComparatorForShapes implements Comparator<Shape3D>
{

    /**
     * Compares and sorts the shapes.
     * @param shape1 shape to compare
     * @param shape2 shape to compare
     * @return if is greater, less or equal.
     */
    @Override
    public int compare(Shape3D shape1, Shape3D shape2) {
        if(shape1.distanceFromOrigin() < shape2.distanceFromOrigin()) return -1;
        if(shape1.distanceFromOrigin() > shape2.distanceFromOrigin()) return 1;
        return 0;
    }
}
