/*
 * File: Parallelepiped.java
 *
 * Purpose: A class that extends Shape3D.
 * Contains the formula the surface area and volume for its respective kind of shape .
 *
 * I affirm that this program is entirely
 * my own work and none of it is the work
 * of any other person.
 */

/**
 * Class for a cone shape.
 *
 * @author JuanS
 */
public class Parallelepiped extends Shape3D
{
    private final int length, width, height; // variables for the shape's measures.
    private final String name = "Parallelepiped"; // variable for the name.

    /**
     * Constructs the shape.
     *
     * @param x x-axis
     * @param y y-axis
     * @param z z-axis
     * @param length size of the length
     * @param width size of the width
     * @param height size of the height
     */
    public Parallelepiped(int x, int y, int z, int length, int width, int height) {
        super(x, y, z);
        this.length = length;
        this.width = width;
        this.height = height;
    }

    /**
     * Returns the name of the shape.
     *
     * @return the name of the shape
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * Formula for the surface area of the shape.
     *
     * @return the surface area of the shape
     */
    @Override
    public double shapeSurface() {
        return (2 * (length * width)) + (2 * (length * height)) + (2 * (width * height));
    }


    /**
     * Formula for the volume of the shape.
     *
     * @return the volume of the shape
     */
    @Override
    public double shapeVolume() {
        return length * width * height;
    }

    /**
     * Method to display the name and the measures of the shape.
     *
     * @return the name and measures of the shape
     */
    @Override
    public String toString() {
        return name +
                "\nCenter: " + super.toString() +
                " Length: " + length+
                " With: " + width +
                " Height: " + height;
    }
}
